#include "linkedlist.hpp"

int list_size(const Node* n) {
}

Cell* list_ith(Node* n, unsigned int i) {
}

Node* list_erase(Node* n, Node* pos) {
}

Node* list_insert(Node* n, Node* pos, Cell* c) {
}

Node* list_insert_int(Node* n, Node* pos, const int value) {
}

Node* list_insert_double(Node* n, Node* pos, const double value) {
}

Node* list_insert_symbol(Node* n, Node* pos, const char* value) {
}
